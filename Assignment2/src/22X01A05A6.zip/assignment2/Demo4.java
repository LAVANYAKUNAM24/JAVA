package assignment2;

public class Demo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String n =args[0];
		try {
			if (n=="COUPON123") {
				System.out.println("coupon applied successfully");
			}else {
				System.out.println("Failed to apply coupon :invalid coupon code");
			}
		}
		
			
		
		finally {
			System.out.println("thank you for shopping with us!!..");
			
		}
		

	}

}